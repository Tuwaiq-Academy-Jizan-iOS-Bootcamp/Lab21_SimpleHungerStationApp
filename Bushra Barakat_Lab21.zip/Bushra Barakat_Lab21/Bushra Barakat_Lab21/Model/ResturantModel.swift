//
//  ResturantModel.swift
//  Bushra Barakat_Lab21
//
//  Created by Bushra Barakat on 11/04/1443 AH.
//

import Foundation
import UIKit
struct Resturant {
    var resturantImage: UIImage
    var resturantLogo: UIImage
    var resturantName: String
    var resturantType: String
    var resturantDeliveryTime: String
    var resturantDeliveryPrice: String
    var resturantRating: String
}
