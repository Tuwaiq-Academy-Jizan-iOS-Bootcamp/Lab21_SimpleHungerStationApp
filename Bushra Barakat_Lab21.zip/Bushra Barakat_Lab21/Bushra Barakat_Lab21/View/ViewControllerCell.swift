//
//  ViewControllerCell.swift
//  Bushra Barakat_Lab21
//
//  Created by Bushra Barakat on 11/04/1443 AH.
//

import Foundation
import UIKit
class ViewControllerCell :UITableViewCell{
    @IBOutlet weak var resturantImageView: UIImageView!
    @IBOutlet weak var resturantLogoImageView: UIImageView!
    @IBOutlet weak var resturantNameLabel: UILabel!
    @IBOutlet weak var resturantTypeLabel: UILabel!
    @IBOutlet weak var resturantDeliveryTimeLabel: UILabel!
    @IBOutlet weak var resturantDeliveryPriceLabel: UILabel!
    @IBOutlet weak var resturantRatingLabel: UILabel!
    
}

