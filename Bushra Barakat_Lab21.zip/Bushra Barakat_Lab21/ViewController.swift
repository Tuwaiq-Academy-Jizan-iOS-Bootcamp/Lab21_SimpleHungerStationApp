//
//  ViewController.swift
//  Bushra Barakat_Lab21
//
//  Created by Bushra Barakat on 11/04/1443 AH.
//

import Foundation
import UIKit
class ViewController: UIViewController{

    @IBOutlet weak var restauTableView: UITableView!
    
    //@IBOutlet weak var restaurantTableView: UITableView!

    
    override func viewDidLoad() {
//        resturantTableView.delegate = self
//        resturantTableView.dataSource = self
        
//        restaurantTableView.dataSource = self
//        restaurantTableView.delegate = self
        
       
        
    }
    
  var resturants = [Resturant(resturantImage: UIImage(named: "herfy")!, resturantLogo: UIImage(named: "herfylogo")!, resturantName: "Herfy", resturantType: "Fast Food",  resturantDeliveryTime: "30 - 40 minute", resturantDeliveryPrice: "10 SR", resturantRating: "3"),
    Resturant(resturantImage: UIImage(named: "applebees")!, resturantLogo: UIImage(named: "applebeeslogo")!, resturantName: "Applebees", resturantType: "American Food",  resturantDeliveryTime: "40 - 50", resturantDeliveryPrice: "20 SR", resturantRating: "5"),
    Resturant(resturantImage: UIImage(named: "balckdose")!, resturantLogo: UIImage(named: "blackdoselogo")!, resturantName: "Black Dose", resturantType: "Coffe", resturantDeliveryTime: "15 - 30 minute", resturantDeliveryPrice: "20", resturantRating: "4.5"),
    Resturant(resturantImage: UIImage(named: "ocanbasket")!, resturantLogo: UIImage(named: "ocanbasketlogo")!, resturantName: "Ocan Basket", resturantType: "Sea Food", resturantDeliveryTime: "40 - 50 minute", resturantDeliveryPrice: "25 SR", resturantRating: "3"),
        ]
    
    
}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return resturants.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! ViewControllerCell
        
        cell.resturantImageView.image = resturants[indexPath.row].resturantImage
        cell.resturantLogoImageView.image =  resturants[indexPath.row].resturantLogo
        cell.resturantNameLabel.text = resturants[indexPath.row].resturantName
        cell.resturantTypeLabel.text = resturants[indexPath.row].resturantType
        cell.resturantDeliveryTimeLabel.text = resturants[indexPath.row].resturantDeliveryTime
        cell.resturantDeliveryPriceLabel.text = resturants[indexPath.row].resturantDeliveryPrice
        cell.resturantRatingLabel.text = resturants[indexPath.row].resturantRating
        

        return cell
       
    }
    
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
////        <#code#>
//    }
    
    
    
    
    
}

